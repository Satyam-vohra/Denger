import os
import json
import sqlite3
from urllib.parse import quote_plus

from flask import Flask, render_template, request, jsonify, send_from_directory
import folium

from twilio.rest import Client
from twilio.twiml.voice_response import VoiceResponse

app = Flask(__name__)
TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID", "AC5efd2158893306ef3f5bfce971ce7946")
TWILIO_AUTH_TOKEN  = os.getenv("TWILIO_AUTH_TOKEN",  "4874c158f68dcf37ea95a9d0cddfdf86")
TWILIO_NUMBER      = os.getenv("TWILIO_NUMBER",      "+18563863829")
MY_NUMBER          = os.getenv("MY_NUMBER",          "+919634892889")

WHATSAPP_ENABLED       = os.getenv("WHATSAPP_ENABLED", "false").lower() == "true"
TWILIO_WHATSAPP_FROM   = os.getenv("TWILIO_WHATSAPP_FROM", "whatsapp:+14155238886")
MY_WHATSAPP_NUMBER     = os.getenv("MY_WHATSAPP_NUMBER",   "whatsapp:+919634892889")

client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

DB_PATH = "project.db"
HELPLINE_FILE = "helplines.json"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS allocations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        area_name TEXT,
        severity INTEGER,
        population INTEGER,
        food INTEGER,
        water INTEGER,
        medical INTEGER,
        shelter INTEGER,
        rescue_teams INTEGER
    )
    """)
    conn.commit()
    conn.close()

class Area:
    def __init__(self, name, severity, population, lat, lon):
        self.name = name
        self.severity = severity
        self.population = population
        self.lat = lat
        self.lon = lon

class Resources:
    def __init__(self, food, water, medical, shelter, rescue_teams):
        self.food = food
        self.water = water
        self.medical = medical
        self.shelter = shelter
        self.rescue_teams = rescue_teams

class Allocation:
    def __init__(self, area, allocated):
        self.area = area
        self.allocated = allocated

def allocate_resources(areas, resources):
    allocations = []
    total_score = sum(area.severity * area.population for area in areas) or 1
    for area in areas:
        share = (area.severity * area.population) / total_score
        allocated = Resources(
            food=int(resources.food * share),
            water=int(resources.water * share),
            medical=int(resources.medical * share),
            shelter=int(resources.shelter * share),
            rescue_teams=int(resources.rescue_teams * share),
        )
        allocations.append(Allocation(area, allocated))
    return allocations

def generate_map(allocations):
    m = folium.Map(location=[allocations[0].area.lat, allocations[0].area.lon], zoom_start=6)
    for alloc in allocations:
        area = alloc.area
        color = "green" if area.severity == 1 else ("orange" if area.severity == 2 else "red")
        popup_text = f"""
        <b>Area:</b> {area.name}<br>
        <b>Severity:</b> {area.severity}<br>
        <b>Population:</b> {area.population}<br>
        <b>Food:</b> {alloc.allocated.food}<br>
        <b>Water:</b> {alloc.allocated.water}<br>
        <b>Medical:</b> {alloc.allocated.medical}<br>
        <b>Shelter:</b> {alloc.allocated.shelter}<br>
        <b>Rescue Teams:</b> {alloc.allocated.rescue_teams}
        """
        folium.CircleMarker(
            location=[area.lat, area.lon],
            radius=10,
            popup=popup_text,
            color=color,
            fill=True,
            fill_color=color
        ).add_to(m)
    os.makedirs("static", exist_ok=True)
    file_path = os.path.join("static", "disaster_map.html")
    m.save(file_path)
    return file_path

def send_sms(text_body, to_number):
    client.messages.create(body=text_body, from_=TWILIO_NUMBER, to=to_number)

def send_whatsapp(text_body):
    if WHATSAPP_ENABLED:
        client.messages.create(body=text_body, from_=TWILIO_WHATSAPP_FROM, to=MY_WHATSAPP_NUMBER)

def place_voice_call(lat, lon, note):
    base = request.url_root.rstrip("/")
    url = f"{base}/voice?lat={quote_plus(str(lat))}&lon={quote_plus(str(lon))}&note={quote_plus(note or '')}"
    client.calls.create(to=MY_NUMBER, from_=TWILIO_NUMBER, url=url)

DEFAULT_HELPLINES = {
    "National Emergency Number": "112",
    "Police": "100",
    "Fire": "101",
    "Ambulance": "102",
    "Disaster Management (NDMA)": "108",
    "Women Helpline": "1091",
    "Women Domestic Abuse Helpline": "181",
    "Child Helpline": "1098",
    "Senior Citizen Helpline": "14567",
    "AIDS Helpline": "1097",
    "Anti-Poison Helpline": "1066",
    "Railway Enquiry": "139",
    "Road Accident Emergency Service": "1073",
    "Earthquake/Flood/Disaster Relief": "1070",
    "Tourist Helpline": "1363",
    "Cyber Crime Helpline": "1930"
}

def ensure_helplines_file():
    if not os.path.exists(HELPLINE_FILE):
        with open(HELPLINE_FILE, "w", encoding="utf-8") as f:
            json.dump(DEFAULT_HELPLINES, f, indent=2, ensure_ascii=False)

def load_helplines():
    ensure_helplines_file()
    with open(HELPLINE_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

@app.route("/")
def index():
    helplines = load_helplines()
    return render_template("index.html", helplines=helplines)

@app.route("/allocate", methods=["POST"])
def allocate():
    areas = []
    num_areas = int(request.form['num_areas'])

    for i in range(num_areas):
        name = request.form[f'name_{i}']
        severity = int(request.form[f'severity_{i}'])
        population = int(request.form[f'population_{i}'])
        lat = float(request.form[f'lat_{i}'])
        lon = float(request.form[f'lon_{i}'])
        areas.append(Area(name, severity, population, lat, lon))
        if severity == 3:
            send_sms(f"🚨 HIGH ALERT: {name} danger zone. Immediate action required!", MY_NUMBER)

    food = int(request.form['food'])
    water = int(request.form['water'])
    medical = int(request.form['medical'])
    shelter = int(request.form['shelter'])
    rescue_teams = int(request.form['rescue_teams'])

    resources = Resources(food, water, medical, shelter, rescue_teams)
    results = allocate_resources(areas, resources)
    map_path = generate_map(results)

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    for alloc in results:
        cur.execute("""
        INSERT INTO allocations (area_name, severity, population, food, water, medical, shelter, rescue_teams)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            alloc.area.name,
            alloc.area.severity,
            alloc.area.population,
            alloc.allocated.food,
            alloc.allocated.water,
            alloc.allocated.medical,
            alloc.allocated.shelter,
            alloc.allocated.rescue_teams
        ))
    conn.commit()
    conn.close()

    return render_template("results.html", allocations=results, map_file=map_path)

@app.route("/history")
def history():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT * FROM allocations ORDER BY id DESC")
    records = cur.fetchall()
    conn.close()
    return render_template("history.html", records=records)

@app.route("/sos", methods=["POST"])
def sos():
    """
    JSON: { lat, lon, note }
    Online: sends SMS (+ optional WhatsApp) and places a voice call.
    Offline is handled at the client by opening native SMS composer.
    """
    data = request.get_json(force=True, silent=True) or {}
    lat = data.get("lat")
    lon = data.get("lon")
    note = (data.get("note") or "").strip()

    if lat is None or lon is None:
        return jsonify({"ok": False, "error": "Location missing"}), 400

    maps_url = f"https://maps.google.com/?q={lat},{lon}"
    text = f"🚨 SOS ALERT!\nLocation: {lat}, {lon}\nMap: {maps_url}"
    if note:
        text += f"\nNote: {note}"

    send_sms(text, MY_NUMBER)
    send_whatsapp(text)
    place_voice_call(lat, lon, note)

    return jsonify({"ok": True})

@app.route("/voice", methods=["GET", "POST"])
def voice():
    lat = request.values.get("lat", "")
    lon = request.values.get("lon", "")
    note = request.values.get("note", "")
    vr = VoiceResponse()
    vr.say("Emergency S O S alert!", voice="alice", language="en-IN")
    if lat and lon:
        vr.say(f"GPS coordinates: latitude {lat}, longitude {lon}.", voice="alice", language="en-IN")
    if note:
        vr.say(f"Additional note: {note}.", voice="alice", language="en-IN")
    vr.say("This is an automated call from your Disaster Relief system.", voice="alice", language="en-IN")
    return str(vr)

@app.route("/helplines")
def helplines_json():
    return jsonify(load_helplines())

@app.route("/service-worker.js")
def sw():
    return send_from_directory("static", "service-worker.js")

@app.route("/manifest.json")
def manifest():
    return send_from_directory("static", "manifest.json")
if __name__ == "__main__":
    init_db()
    ensure_helplines_file()
    app.run(debug=True)
