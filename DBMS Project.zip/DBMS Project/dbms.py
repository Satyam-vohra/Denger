import folium
import webbrowser

class Area:
    def __init__(self, name, severity, population, lat, lon):
        self.name = name
        self.severity = severity  
        self.population = population
        self.lat = lat
        self.lon = lon

class Resources:
    def __init__(self, food, water, medical, shelter, rescue_teams):
        self.food = food
        self.water = water
        self.medical = medical
        self.shelter = shelter
        self.rescue_teams = rescue_teams

class Allocation:
    def __init__(self, area, allocated):
        self.area = area
        self.allocated = allocated

def allocate_resources(areas, resources):
    allocations = []

    total_score = sum(area.severity * area.population for area in areas)

    for area in areas:
        share = (area.severity * area.population) / total_score

        allocated = Resources(
            food=int(resources.food * share),
            water=int(resources.water * share),
            medical=int(resources.medical * share),
            shelter=int(resources.shelter * share),
            rescue_teams=int(resources.rescue_teams * share),
        )

        allocations.append(Allocation(area, allocated))
    return allocations

def generate_map(allocations):

    m = folium.Map(location=[allocations[0].area.lat, allocations[0].area.lon], zoom_start=6)

    for alloc in allocations:
        area = alloc.area

        # Zone colors
        if area.severity == 3:
            color = "red"       # High severity
        elif area.severity == 2:
            color = "orange"    # Medium severity
        else:
            color = "green"     # Low severity

        popup_text = f"""
        <b>Area:</b> {area.name}<br>
        <b>Severity:</b> {area.severity}<br>
        <b>Population:</b> {area.population}<br>
        <b>Food:</b> {alloc.allocated.food}<br>
        <b>Water:</b> {alloc.allocated.water}<br>
        <b>Medical:</b> {alloc.allocated.medical}<br>
        <b>Shelter:</b> {alloc.allocated.shelter}<br>
        <b>Rescue Teams:</b> {alloc.allocated.rescue_teams}
        """

        folium.CircleMarker(
            location=[area.lat, area.lon],
            radius=10,
            popup=popup_text,
            color=color,
            fill=True,
            fill_color=color
        ).add_to(m)

    file_name = "disaster_map.html"
    m.save(file_name)

    webbrowser.open(file_name)

def main():
    print("=== Disaster Relief Resource Allocation System ===\n")

    n = int(input("Enter number of affected areas: "))
    areas = []

    for i in range(n):
        print(f"\nEnter details for Area {i+1}:")
        name = input("  Name: ")
        severity = int(input("  Severity (1=Low, 2=Medium, 3=High): "))
        population = int(input("  Population affected: "))

        print(" Enter Latitude/Longitude in Decimal format ")
        lat = float(input("  Latitude: "))
        lon = float(input("  Longitude: "))

        areas.append(Area(name, severity, population, lat, lon))

    print("\nEnter available resources:")
    food = int(input("  Food packets: "))
    water = int(input("  Water bottles: "))
    medical = int(input("  Medical kits: "))
    shelter = int(input("  Shelter units: "))
    rescue_teams = int(input("  Rescue teams: "))

    resources = Resources(food, water, medical, shelter, rescue_teams)

    results = allocate_resources(areas, resources)

    print("\n=== Allocation Results (Auto Danger Zone Based) ===")
    for alloc in results:
        print(f"\nArea: {alloc.area.name} (Severity: {alloc.area.severity}, Population: {alloc.area.population})")
        print(f"  Food Packets   : {alloc.allocated.food}")
        print(f"  Water Bottles  : {alloc.allocated.water}")
        print(f"  Medical Kits   : {alloc.allocated.medical}")
        print(f"  Shelter Units  : {alloc.allocated.shelter}")
        print(f"  Rescue Teams   : {alloc.allocated.rescue_teams}")

    generate_map(results)
if __name__ == "__main__":
    main()
